UG Metrics / 03 CUT
Three raster PNG assets: lavender logo, cream logo, circular avatar. Transparent backgrounds. Original generated logo direction inspired by observed cover-art treatments. No vector master included.
